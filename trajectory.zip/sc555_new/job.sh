#!/bin/bash
#SBATCH -o slurm.out
#SBATCH -e slurm.err
#SBATCH -J 720K_MD
##SBATCH -p delairelab
#SBATCH -p scavenger
#SBATCH -n 24

##SBATCH --mem=40G
#source /opt/apps/intel/intelvars.sh
#export PATH=/usr/local/cuda/bin:$PATH
#export I_MPI_PMI_LIBRARY=/opt/slurm/lib64/libpmi.so

ulimit -s unlimited

module load Anaconda3

source /opt/apps/rhel7/intel_2018/compilers_and_libraries/linux/bin/compilervars.sh intel64
export PATH=/opt/apps/rhel7/openmpi-4.0.2-intel-18.0.2/bin:$PATH
export LD_LIBRARY_PATH=/opt/apps/rhel7/openmpi-4.0.2-intel-18.0.2/lib:$LD_LIBRARY_PATH
#export I_MPI_PMI2=yes
ulimit -s unlimited

srun --mpi=pmi2 /hpc/home/xh59/.conda/envs/deepmd/bin/lmp -in in.lammps > log.lammps 
